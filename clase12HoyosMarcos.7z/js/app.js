/*
    Proyecto: Sitio Web Ecommerce
    Nombre: Epsilon Camisetas
    Descripción: Sitio de venta de productos deportivos.
*/

$(document).ready(function(){
    alert("la pagina se cargo JQUERY...");
});