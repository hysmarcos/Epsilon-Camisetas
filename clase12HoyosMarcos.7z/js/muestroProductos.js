// var listProductsCart = document.getElementById('carrito');
// var th = document.createElement("th");
// var td = document.createElement("td");
// th.appendChild(td)
// listProductCart.forEach(element => {
//     carrito.appendChild()
// });
// var row =  listProductsCart.insertRow();
