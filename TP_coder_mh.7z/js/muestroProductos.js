// let productosCarrito = "";

// productosCarrito += `<tr>`;
// clientLocalStorage.pedido.forEach( prod => {
//     productosCarrito +=`
//     <th scope="row"><img src="${prod.imagen}" alt="${prod.nombre}" srcset=""></th>
//     <td>${prod.nombre}</td>
//     <td>${prod.precio}</td>
// `
// });
// productosCarrito += `</tr>`;