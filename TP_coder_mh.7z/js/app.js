/*
    Proyecto: Sitio Web Ecommerce
    Nombre: Epsilon Camisetas
    Descripción: Sitio de venta de productos deportivos.
*/

// Muestro productos mediante js
//MuestroProductosHome();

// Registro Usuario, o lo recupero mediante localStorage
RegistroUsuario();

// Actualizo icono carrito de navbar
CambioEstadoCarrito();

// Muestro productos en el Home del sitio
var productosCatCamisetas = '';
productosCatCamisetas = MuestroProductosHome();